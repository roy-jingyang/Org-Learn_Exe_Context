# Built on the original R implementation code available at:
# https://doi.org/10.5281/zenodo.4606757
# Reference:
# van Hulzen, G., Martin, N., & Depaire, B. (2021). Looking Beyond Activity
# Labels: Mining Context-Aware Resource Profiles Using Activity Instance
# Archetypes. In A. Polyvyanyy, M. T. Wynn, A. Van Looy, & M. Reichert (Eds.),
# Business Process Management Forum - BPM Forum 2021, Rome, Italy, September
# 06-10, 2021, Proceedings (pp. 230–245). Springer.

lib_loc <- paste(getwd(), "/r_lib", sep="")

#require(dplyr)
#require(lubridate)
#require(stringr)
#require(fastDummies)
#require(flexmix)

#install.packages("dplyr", repos="https://cloud.r-project.org",lib=lib_loc)
#install.packages("lubridate", repos="https://cloud.r-project.org",lib=lib_loc)
#install.packages("stringr", repos="https://cloud.r-project.org",lib=lib_loc)
#install.packages("fastDummies", repos="https://cloud.r-project.org",lib=lib_loc)
#install.packages("flexmix", repos="https://cloud.r-project.org",lib=lib_loc)

library(dplyr, lib.loc = lib_loc)
library(lubridate, lib.loc = lib_loc)
library(stringr, lib.loc = lib_loc)
library(fastDummies, lib.loc = lib_loc)
library(flexmix, lib.loc = lib_loc)

args <- commandArgs(trailingOnly = TRUE)
if (length(args) == 2) {
    fn <- args[1]
    k <- as.integer(args[2])
} else {
    stop("Need to specify two arguments `fn` (filename) and `k` (number of components)")
}

print(fn)
print(k)

# Read event log
bpic2017 <- read.csv(
    file = fn,
    header = TRUE, 
    encoding = "UTF-8", 
    fileEncoding = "UTF-8-BOM", 
    stringsAsFactors = TRUE
)

# Preprocess data
# load and transform columns
bpic2017 <- bpic2017 %>%
    select(
        "case.LoanGoal",
        "case.ApplicationType",
        "case.concept.name",
        "concept.name",
        "org.resource",
        "time.timestamp"
    ) %>%
    rename(
        CaseID = "case.concept.name",
        CaseLoanGoal = "case.LoanGoal",
        CaseApplicationType = "case.ApplicationType",
        Activity = "concept.name",
        CompleteTimestamp = "time.timestamp",
        Resource = "org.resource"
    ) %>%
    mutate(
        CaseID = as.factor(CaseID),
        CaseLoanGoal = as.factor(CaseLoanGoal),
        CaseApplicationType = as.factor(CaseApplicationType),
        CompleteTimestamp = ymd_hms(CompleteTimestamp),
        Resource = as.factor(Resource),
        Activity = as.factor(Activity),
        Month = as.factor(month(CompleteTimestamp, label = FALSE)),
        Weekday = as.factor(wday(CompleteTimestamp, label = FALSE, week_start = 1))
    )
bpic2017 <- as.data.frame(bpic2017)

# Run clustering with manual loop to store all models
modelBIC <- list()
niter <- 20
for (i in 1:niter) {
    cat(paste0("=== Iter ", i, " ===\n"))
    set.seed(i)
    model <- stepFlexmix(
        formula = . ~ 1,
        data = bpic2017,
        k = k,
        nrep = 5,
        model = list(
            FLXMRmultinom(Resource ~ .),

            FLXMRmultinom(CaseLoanGoal ~ .),
            FLXMRmultinom(CaseApplicationType ~ .),

            FLXMRmultinom(Activity ~ .),

            FLXMRmultinom(Month ~ .),
            FLXMRmultinom(Weekday ~ .)
        ),
        control = list(
            verbose = 1,
            tolerance = 1e-06,
            iter.max = 500
        )
    )
    # model = getModel(models, as.character(k))
    newCol <- paste0("ClusterRep", "_", i)
    bpic2017[[newCol]] <- clusters(model)
    val <- paste0("BICRep", "_", i)
    modelBIC[[val]] <- BIC(model)
}

# Export
fnOut <- paste0(fn, ".", "k_", k)
bpic2017 %>% saveRDS(paste0(fnOut, ".RDS"))
write.csv(bpic2017, paste0(fnOut, ".csv"))

print("Finished. Clustering results are exported to RDS and CSV.")

print("BIC values:")
cat(unlist(modelBIC), sep = ",")
cat("\n")

print(paste0("Mean BIC value: ", mean(unlist(modelBIC))))
